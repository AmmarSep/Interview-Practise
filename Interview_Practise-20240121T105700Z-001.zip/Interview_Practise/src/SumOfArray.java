public class SumOfArray {
    public static void main(String[] args) {
        int[] array = new int[]{34,35,25,32};
        int sum= 0;
        for(int i =0; i< array.length; i++){
sum = sum + array[i];
        }
        System.out.println(+sum);
    }
}
